import "./scripts/components/header-bar.js";
import "./scripts/components/footer-bar.js";

import "./scripts/components/note-form.js";

import "./styles/style.css";
